<?php

use Illuminate\Database\Seeder;
use App\Photo;

class PhotosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Let's truncate our existing records to start from scratch.
        Photo::truncate();

        $faker = \Faker\Factory::create();

        // create the custom data for is_visible
        $is_visibles = ['visible', ''];

        $filePath = public_path('storage/images');

        // if(!File::exists($filepath)) {
        //     File::makeDirectory($filepath);  //follow the declaration to see the complete signature
        // }

        // And now, let's create a few articles in our database:
        for ($i = 0; $i < 50; $i++) {
            Photo::create([
                'user_id' => rand(0, 10),
                'title' => $faker->sentence,
                'description' => $faker->paragraph,
                'picture' => 'random.jpg', // $faker->image('public/storage/images',400,300, null, false) ,
                'is_visible' => $faker->boolean(), // $is_visibles[rand(0, count($is_visibles) - 1)],
            ]);
        }
    }
}
