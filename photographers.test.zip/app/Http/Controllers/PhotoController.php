<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Photo;
use Validator;
use Carbon\Carbon;
use Image;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Response;
use Storage;
use DB, Mail;

class PhotoController extends Controller
{
    public function index()
    {
        return Photo::all();
    }

    public function show(Photo $photo)
    {
        return $photo;
    }

    public function store(Request $request)
    {
        $photo = Photo::create($request->all());

        return response()->json($photo, 201);
    }

    public function update(Request $request, Photo $photo)
    {
        $photo->update($request->all());

        return response()->json($photo, 200);
    }

    public function delete(Photo $photo)
    {
        $photo->delete();

        return response()->json(null, 204);
    }

    public function upload(Request $request)
    {
        $input = $request->all();

        $messages = [
            'image64' => 'The :attribute must be a file of type: :values.',
        ];

        $validator = Validator::make($input, [
            'picture' => 'required|image64:image/jpeg, image/jpg, image/png',
            'title' => 'required'
        ], $messages);

        if ($validator->fails()) {
            return response()->json(['errors'=>$validator->errors()]);
        }

        $imageData = $request->get('picture');
        $fileName = Carbon::now()->timestamp . '_' . uniqid() . '.' . explode('/', explode(':', substr($imageData, 0, strpos($imageData, ';')))[1])[1];
        $input['picture'] = $fileName;

        if(Image::make($request->get('picture'))->save(public_path('storage/images/').$fileName)) {
            $input['user_id'] = Auth::user()->id;
            $photo = Photo::create($input);
            return response()->json(['success' => true, 'photoinfo' => $photo], 201);
        }
        return response()->json(['success' => false], 200);
    }

    public function photosMine()
    {
        $photos_mine = Photo::where('user_id', Auth::user()->id)
               ->orderBy('created_at', 'desc')
               ->take(100)
               ->get();
        return response()->json(['success' => true, 'photos_mine' => $photos_mine], 200);
    }

    public function photoShared()
    {
        $user = Auth::user();
        // $sharedPhotoIds = DB::table('user_shared_photos')->select('photo_id')->where(['with_email' => $user->email])->get()->unique();
        $sharedPhotos = DB::table('user_shared_photos')
            ->leftJoin('photos', 'photos.id', '=', 'user_shared_photos.photo_id')
            ->where('user_shared_photos.with_email', $user->email)
            ->get()
            ->unique();
        return response()->json(['data' => $sharedPhotos], 200);
        
        // return response()->json(['success' => true, 'photos_mine' => $photos_mine], 200);
    }

    public function downloadPhoto(Request $request)
    {
        $url = "https://cdn.psychologytoday.com/sites/default/files/blogs/38/2008/12/2598-75772.jpg";
        $name = 'happy.jpg';

        // $image = Image::make($url)->encode('jpg');
        $headers = [
            'Content-Type' => 'image',
            'Content-Disposition' => 'attachment; filename='. $name,
        ];
        // return response()->stream(function() use ($image) {
        //     echo $image;
        // }, 200, $headers);
        // return response()->streamDownload(function () {
        //     echo file_get_contents($url);
        // }, $name);
        // return response()->streamDownload(function () {
        //     echo file_get_contents('https://cdn.psychologytoday.com/sites/default/files/blogs/38/2008/12/2598-75772.jpg');
        // }, 'nice-name.jpg');
        return response()->download(public_path('storage/images/1527396133_5b0a3725e1fc2.jpeg'), $name, $headers);
        // $url = public_path('storage/images/1527396133_5b0a3725e1fc2.jpeg'); // "http://www.google.co.in/intl/en_com/images/srpr/logo1w.png";
        // $contents = file_get_contents($url);
        // $name = substr($url, strrpos($url, '/') + 1);
        // Storage::put($name, $contents);
        // $headers = array(
        //     'Content-Type: image/jpg',
        //     'Content-disposition: attachment; filename: nameToFile.jpg'
        // );
        // return response()->download(public_path('storage/images/1527396133_5b0a3725e1fc2.jpeg'), $name, $headers);
    }

    public function sharePhoto(Request $request)
    {
        $user = Auth::user();
        $inputs = $request->only(['with_email', 'photo_id']);
        $name = '';
        $email = $inputs['with_email'];
        // return response()->json($inputs);

        DB::table('user_shared_photos')->insert(['user_id'=>$user->id,'photo_id'=> $inputs['photo_id'], 'with_email' => $inputs['with_email']]);

        $subject = $user->name . '<' . $user->email . '> shared a photo '. $inputs['photo_id'] . 'with you.';
        Mail::send('email.sharephoto', ['name' => $email, 'from_name' => $user->name, 'from_email' => $user->email, 'photo_id' => $inputs['photo_id']],
            function($mail) use ($email, $name, $subject){
                $mail->from(getenv('FROM_EMAIL_ADDRESS'), "Photographers Ltd.");
                $mail->to($email, $name);
                $mail->subject($subject);
            });

        return response()->json(['success' => true, 'message' => 'Your photo is shared by mail!...'], 200);
    }
}
