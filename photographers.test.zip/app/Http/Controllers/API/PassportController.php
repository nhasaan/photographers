<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\Auth;
use Validator;
use DB, Hash, Mail;
use Illuminate\Mail\Message;

class PassportController extends Controller
{
    public $successStatus = 200;

    /**
     * login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request){
    	$credentials = $request->only('email', 'password');
    	// return response()->json([$credentials, Auth::attempt($credentials), Auth::user(), Auth::user()->createToken('MyToken')]);
        if(Auth::attempt($credentials)){
            $user = Auth::user();
            $userData['token'] =  $user->createToken('MyToken')->accessToken;
            $userData['userinfo'] =  $user;
            $userData['isAuthenticated'] = true;
            return response()->json(['success' => true, 'userData' => $userData], $this->successStatus);
        }
        else{
            return response()->json(['error'=>'Unauthorised'], 401);
        }
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'c_password' => 'required|same:password',
        ]);

		if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 401);
        }

		$input = $request->all();
		// return response()->json($input);

        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);
        // $success['token'] =  $user->createToken('MyToken')->accessToken;
        $success['name'] = $name = $user->name;
        $email =  $user->email;
        $success['message'] =  'Thanks for signing up! Please check your email to complete your registration.';

		$verification_code = str_random(30);
        DB::table('user_verifications')->insert(['user_id'=>$user->id,'token'=>$verification_code]);

        $subject = "Please verify your email address.";
        Mail::send('email.verify', ['name' => $name, 'verification_code' => $verification_code],
            function($mail) use ($email, $name, $subject){
                $mail->from(getenv('FROM_EMAIL_ADDRESS'), "Photographers Ltd.");
                $mail->to($email, $name);
                $mail->subject($subject);
            });
        // return response()->json(['success'=> true, 'message'=> 'Thanks for signing up! Please check your email to complete your registration.']);

        return response()->json(['success'=>$success], $this->successStatus);
    }

	public function details()
    {
        $user = Auth::user();
        return response()->json(['success' => $user], $this->successStatus);
    }

    public function verifyUser($verification_code)
    {
        $check = DB::table('user_verifications')->where('token',$verification_code)->first();
        if(!is_null($check)){
            $user = User::find($check->user_id);
            if($user->is_verified == 1){
                return response()->json([
                    'success'=> true,
                    'message'=> 'Account already verified..'
                ]);
            }
            $user->update(['is_verified' => 1]);
            DB::table('user_verifications')->where('token',$verification_code)->delete();
            return response()->json([
                'success'=> true,
                'message'=> 'You have successfully verified your email address.'
            ]);
        }
        return response()->json(['success'=> false, 'error'=> "Verification code is invalid."]);
    }
}
