<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Photo extends Model
{
    // define the fillable fields
    protected $fillable = ['user_id', 'picture', 'title', 'description', 'is_visible'];
}
