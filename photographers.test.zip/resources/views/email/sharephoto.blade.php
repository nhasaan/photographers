<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
    Hi {{ $name }},
    <br>
    Nice to see you here. Your friend {{ $from_name }} <{{ $from_email }}> just shared a photo!
    <br>
    Please click on the link below to download the photo:
    <br>

    <a href="{{ url('http://localhost:3000/admin/sharephoto') }}">Download this photo?</a>

    <br/>
</div>

</body>
</html>
